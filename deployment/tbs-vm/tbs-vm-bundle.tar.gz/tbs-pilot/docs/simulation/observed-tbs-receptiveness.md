# TBS receptiveness pilot with observed-behaviour personalisation

Prepared on **16 November 2026** using
[`observed-tbs-receptiveness.json`](observed-tbs-receptiveness.json) and
[`observed-profile-tbs-pilot.json`](observed-profile-tbs-pilot.json).
Output: `socratic_prototype/data/observed_tbs_receptiveness_20261116/`.

Launched on **16 November 2026 at 18:53 CET** with eight worker processes.
The frozen root manifest is
`af141caf05a0fd3ff3b78c6224971c027fdcc818cbdd188fac869bc554b1c718`.

## Matched design

- TBS only: full **192 trials**, comprising 24 blocks of eight decisions, for
  each unassisted calibration and each comparison condition.
- The same **16 development actors** as the completed MAB pilot: four each in
  MAB-specialised, TBS-specialised, Dual-regime and Low-expression. These labels
  are descriptive researcher information, not assistant inputs. The 46 evaluation
  actors remain untouched.
- Three matched repetitions at receptiveness **0.25, 0.50 and 0.75**.
- All five conditions **A/C/E/D/F** run fresh at every level. There are
  **144 jobs**, 720 comparison sessions and 144 calibrations: 138,240 comparison
  trials and 27,648 calibration trials. No earlier assisted outcomes are reused.
- A single TBS response rule; `current` is retained only as a historical format
  label. There are no `none` or `recent` experimental factors.
- True receptiveness is identical across actors and assistance styles at each
  level. Additional reactance, distraction and AI-induced omission are zero.
  Actor-specific baseline omission rates remain active.
- The seed is `reconsideration-development16-v1`. Independent keyed random
  streams for choices, omissions, offers, targets and outcomes omit condition,
  receptiveness and session identifiers. Actor experience and assistant interaction
  history reset before every comparison. Within a job, E/F receive the same
  generated TBS calibration; C/D use common task-aware delivery inputs.

The primary outcome is **target-attainment rate**, `targets_attained / 24`.
Paired assisted-minus-A differences are displayed in **percentage points**.
Completed-block score, including the conditional final-win multiplier, is a
secondary outcome in multiplied points. Primary and secondary units are kept
separate. Individual results average three paired repetitions before group
means; repetitions do not create extra participants. C/E/D/F stay separate even
when results coincide, and both gains and harms are retained.

## Assistance and response assumptions

The runtime is the same observed-behaviour personalisation implementation used
in the completed MAB study: `policy-0.7` and `participant-model-0.2`. The graph
supplies reasons, objections and accepted comparisons; the intervention policy
decides timing, eligibility and delivery. E/F can adapt from permitted public
task choices and uncertain style-specific uptake estimates. C/D do not receive
those personalised estimates. A remains unassisted.

TBS has two available actions. Restricting a Socratic response to both would leave
the actor's distribution unchanged. This pilot therefore retains the existing
task-owned evidence-processing rule in `tasks/tbs_execution.py`:

- Direct assistance targets the graph-supported recommended action.
- Socratic guidance compares SAFE and RISKY. An `expected_value_limit` issue
  before the final decision weights the actions by their displayed immediate
  expected points. On a final decision, positive target-attainment values are
  normalised, accounting for the conditional multiplier. Other cases weight
  actions by `probability * max(1, amount) / (1 + abs(amount - required_per_trial))`.
- Both styles mix their processing target with the actor's baseline using the
  configured receptiveness. Task processing assumptions differ between styles;
  this is not the MAB singleton/pair rule or a multi-trial optimal planner.

The assistant's TBS observer has 25 pressure-logistic hypotheses and is simpler
than the private empirical actor. Its uncertain forecasts can be misspecified.
An inferred uptake coefficient is conditional on those forecasts, not a measured
attitude, trust score or causal benefit estimate. No beneficial personalisation
contrast or C/E–D/F separation is enforced.

The private actor retains the provisional **seven-feature state/feedback model**
from the colleague's handover. Historical offers remain unavailable; exported
`offer_sensitivity: 0` is retained, rather than fitting or inventing offer effects.
New offers and targets follow the current task generator's independent uniform
sampling. Baseline omissions are independent Bernoulli draws from the frozen
actor estimates. The [empirical-model limitations](../empirical_profiles.md#interpretation-limits),
including the negative held-out TBS prediction result, remain applicable.

Language is offline/bounded. Active synthetic reading exposure is 7,000 ms.
Actors process structured intervention records, not natural language, and do not
generate helpfulness, disagreement or burden reports. These results will assess
the specified synthetic mechanisms, not establish effects on human participants.

## Controls, analysis and parallel execution

The new coordinator is `scripts/tbs_receptiveness_sweep.py`, outside the frozen
runtime package. Earlier MAB runners, source snapshots and reports are preserved.
It uses eight independent worker processes on the eight detected local CPUs,
with one numerical-library thread per worker. Jobs are ordered by repetition,
interleaving original profile groups and receptiveness levels. Each worker has
its own SQLite store and immutable numbered attempts; only the coordinator writes
shared status and analysis. `caffeinate -i` prevents idle system sleep.

Before execution, 48 full unassisted trajectories are independently reconstructed
without graph inference or assistance. Every new A must match the expected
choice/outcome trajectory, choice distributions, omissions, target count and
score. Every completed job additionally replays all 960 comparison trials and
five sets of block metrics before committing. This is numerical replay, not a
second independent graph/SHACL implementation.

Calibration profiles and complete evaluation/feedback inputs are compared across
receptiveness levels, normalising session identifiers only. These signatures
include displayed option amounts/probabilities, targets, horizons and multipliers,
as well as choices, omissions, outcomes and points. A complete grid has 144 fresh
A checks and 96 cross-level calibration checks.

Each level freezes actor inputs, source and dependency fingerprints. The root
manifest also freezes the coordinator and scheduler. Execution rejects altered
software, incomplete protocols, missing conditions, inconsistent rate denominators,
changed baseline streams or calibration drift. Do not change the executable
`socratic_prototype/` package, this coordinator or `scripts/pilot_parallel.py`
while the experiment is running.

`analysis.json` and `analysis.md` update after committed jobs. Primary actor
summaries require all three repetitions, all three levels and all five conditions.
The separately labelled `first_repetition` preview requires all levels/conditions
of repetition zero. Partial completion never silently increases or changes the
denominator. Full group/individual heatmaps and receptiveness trend plots can be
generated after completion from these records.

The initial planning allowance is **18–30 hours** with eight workers, informed
by the preceding MAB run rather than a measured full TBS throughput. The runner
publishes an updated estimate after completed jobs; early estimates may change.

## Start, monitor and resume

All **36 preflight tests passed**, covering the new coordinator, observed
personalisation and single-response contracts. A separate real short-protocol
simulator check replayed 240 trials at receptiveness 0 and .75, including all
five zero-response controls and unchanged fresh A across levels. C/E/D/F each
changed choice probabilities in the nonzero-response check. Those engineering
sessions are excluded from the pilot. `preflight.json` and copied logs in the
output root record the checks. All 48 independent full baseline trajectories
were reconstructed and verified before workers were launched.

Prepare and validate the frozen plan without executing comparison jobs:

```bash
PYTHONPATH=. .venv/bin/python scripts/tbs_receptiveness_sweep.py \
  --config docs/simulation/observed-tbs-receptiveness.json \
  --output-dir socratic_prototype/data/observed_tbs_receptiveness_20261116 \
  --workers 8 --prepare-only
```

Start a prepared grid, or resume an interrupted grid after all previous workers
have exited:

```bash
PYTHONPATH=. caffeinate -i .venv/bin/python -u scripts/tbs_receptiveness_sweep.py \
  --output-dir socratic_prototype/data/observed_tbs_receptiveness_20261116 \
  --workers 8
```

The runner sets offline language mode and single-thread numerical settings before
loading the simulation package. Monitor:

```bash
tail -f socratic_prototype/data/observed_tbs_receptiveness_20261116/sweep.log
cat socratic_prototype/data/observed_tbs_receptiveness_20261116/status.json
```

For a graceful stop, create `stop-after-jobs.json` in the output root. Current
jobs finish and commit, then scheduling stops. Remove that request before
resuming. Exclusive inherited leases prevent concurrent coordinators. Existing
completed results are retained and checked; missing jobs get new numbered
attempts. The output directory must never be re-prepared with changed software.
