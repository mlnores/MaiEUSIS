"""Local durable store. Public events only; evaluator truth stays in browser logs."""
import copy
import hashlib
import json
import sqlite3
import uuid
from datetime import datetime,timezone
from pathlib import Path
from threading import RLock
from contextlib import contextmanager
from .engine import POLICY, NETWORK, ingest, history
from .models import calibration_profile, VERSION
from .validation import fields, require, identity, CONDITIONS, turtle, shacl_report
from .language import configuration as language_configuration
from .grounding import VERSION as GROUNDING_VERSION
from .tasks import get_task,available_tasks
from .tasks.base import SCHEMA_VERSION
from .tasks.tbs import RULES  # Compatibility import for the original task/demo API.
from .study import required_calibrations
from .argumentation import configuration as argumentation_configuration

# JSON roundtrip makes pairs lists consistently across SQLite and initial state.
RULES=json.loads(json.dumps(RULES))
CONFIGURATION_FIELDS=['task','condition','phase','protocol','initial_preference','seed','total_trials','policy','task_rules',
                      'network','model_version','schema_version','calibration_sources','calibration_profile']


def now():return datetime.now(timezone.utc).isoformat()

def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def configuration_fields(session):
    # Legacy traces remain inspectable/replayable without retroactively adding fields.
    return CONFIGURATION_FIELDS+([k for k in ['language_configuration','task_module','argumentation_configuration','participant_model_version','synthetic_run','study_configuration'] if k in session])


class Store:
    def __init__(self,path):
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
        self.lock=RLock()
        with self.connect() as c:c.execute('CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, body TEXT NOT NULL)')

    @contextmanager
    def connect(self):
        connection=sqlite3.connect(self.path,timeout=10)
        try:
            with connection:yield connection
        finally:connection.close()

    def save(self,s):
        with self.connect() as c:c.execute('INSERT OR REPLACE INTO sessions VALUES (?,?)',(s['id'],json.dumps(s)))

    def get(self,sid):
        require(identity(sid) and len(sid)<=55,'Invalid session ID (maximum 55 characters)')
        with self.connect() as c:r=c.execute('SELECT body FROM sessions WHERE id=?',(sid,)).fetchone()
        if r is None:raise KeyError('Session not found')
        return json.loads(r[0])

    def list(self,participant=None):
        with self.connect() as c:rows=c.execute('SELECT body FROM sessions ORDER BY rowid DESC').fetchall()
        result=[]
        for row in rows:
            s=json.loads(row[0])
            if participant and s['participant_id']!=participant:continue
            result.append({k:s[k] for k in ['id','participant_id','task','condition','phase','protocol','created_at','finished','completed','total_trials']}|{'trials':len(history(s))})
        return result

    def create(self,data,*,synthetic_profile=None,synthetic_run=None,study=None):
        fields(data,['participant_id','task','condition','phase','protocol','preference'],['id','calibration_ids','seed'])
        require(identity(data['participant_id']),'Use a pseudonymous participant ID (letters, digits, dash, underscore)')
        if study is not None:
            from .study import validate_study
            study=validate_study(study)
            require(data['task'] in study['tasks'],'Task is not in the selected study')
            require(data['protocol']==study['tasks'][data['task']]['protocol'],'Protocol differs from study configuration')
            require(data['phase']=='calibration' or data['condition'] in study['conditions'],'Condition is not in this study')
        task=get_task(data['task'])
        require(data['condition'] in CONDITIONS,'Unknown condition')
        require(data['phase'] in {'calibration','assisted'},'Unknown phase')
        require(data['protocol'] in task.PROTOCOLS,'Unknown protocol')
        require(data['preference'] in POLICY['cooldown'],'Unknown prompt frequency')
        require(data['phase']!='calibration' or data['condition']=='A','Calibration must be unassisted')
        sid=data.get('id') or 'socratic_'+uuid.uuid4().hex
        require(identity(sid) and len(sid)<=55,'Invalid session ID (maximum 55 characters)')
        require(isinstance(data.get('seed',sid),str) and len(data.get('seed',sid))<=100,'Invalid random seed')
        calibration={}; profile=None
        if data['phase']=='assisted':
            ids=data.get('calibration_ids',{})
            require(isinstance(ids,dict) and set(ids)==set(required_calibrations(task.ID,study)),'Comparison sessions require completed unassisted calibration for the configured study tasks')
            for calibration_task,source_id in ids.items():
                require(bool(source_id),f'Comparison sessions require a completed {calibration_task} calibration. Complete it with the same participant pseudonym and protocol, then select it.')
                require(identity(source_id) and len(source_id)<=55,f'Invalid {calibration_task} calibration selection. Choose a completed calibration from the list.')
                try:source=self.get(source_id)
                except KeyError:
                    raise ValueError(f'The selected {calibration_task} calibration was not found in this data directory. Refresh the page and select a completed calibration.') from None
                require(source['task']==calibration_task and source['participant_id']==data['participant_id'] and source['phase']=='calibration' and source['completed'],f'The selected {calibration_task} calibration must be completed and belong to this participant.')
                require(source['protocol']==(study['tasks'][calibration_task]['protocol'] if study else data['protocol']),'Calibration and assisted protocol must match')
                require(source['model_version']==VERSION,'Calibration model version differs')
                if 'task_module' in source:require(source['task_module']==get_task(source['task']).describe(),'Calibration task module or ontology version differs')
                calibration[calibration_task]={'session_id':source_id,'profile':source['profile'],'digest':digest(source['events'])}
                if source.get('synthetic'):
                    calibration[calibration_task]['synthetic']=True
                    calibration[calibration_task]['synthetic_profile']=copy.deepcopy(source.get('synthetic_profile'))
            if data['condition'] in {'E','F'}:profile=calibration[data['task']]['profile']
        s={'id':sid,'participant_id':data['participant_id'],'task':data['task'],'condition':data['condition'],
           'phase':data['phase'],'protocol':data['protocol'],'preference':data['preference'],'initial_preference':data['preference'],
           'seed':data.get('seed',sid),'created_at':now(),'events':[],'finished':False,'completed':False,
           'total_trials':task.PROTOCOLS[data['protocol']],
           'policy':copy.deepcopy(POLICY),'task_rules':task.task_rules(),'network':NETWORK.describe(),
           'model_version':VERSION,'schema_version':SCHEMA_VERSION,'task_module':task.describe(),
           'calibration_sources':calibration,'calibration_profile':profile}
        if study is not None:s['study_configuration']=copy.deepcopy(study)
        if synthetic_profile is not None:
            fields(synthetic_profile,['name','version','description','notice'])
            require(data['phase']=='calibration' and synthetic_profile['name']==data['participant_id'],'Synthetic profile must identify its calibration participant')
            s['synthetic']=True;s['synthetic_profile']=copy.deepcopy(synthetic_profile)
        if synthetic_run is not None:
            fields(synthetic_run,['version','agent_version','response_version'])
            s['synthetic']=True;s['synthetic_run']=copy.deepcopy(synthetic_run)
        if any(source.get('synthetic') for source in calibration.values()):s['uses_synthetic_calibration']=True
        from .participant_model import VERSION as PARTICIPANT_MODEL_VERSION
        s['participant_model_version']=PARTICIPANT_MODEL_VERSION
        s['language_configuration']={**language_configuration(),'grounding_version':GROUNDING_VERSION}
        s['argumentation_configuration']=argumentation_configuration(task)
        s['configuration_digest']=digest({k:s[k] for k in configuration_fields(s)})
        with self.lock:
            with self.connect() as c:
                try:c.execute('INSERT INTO sessions VALUES (?,?)',(sid,json.dumps(s)))
                except sqlite3.IntegrityError:raise ValueError('Session ID already exists')
        return s

    def event(self,sid,data):
        with self.lock:
            s=self.get(sid)
            require(s.get('argumentation_configuration',{}).get('mode')=='live','Historical session uses an earlier reasoning policy; export it or start a new session')
            if 'task_module' in s:require(s['task_module']==get_task(s['task']).describe(),'Task module or ontology changed; start a new session with the current version')
            if 'argumentation_configuration' in s:require(s['argumentation_configuration']==argumentation_configuration(get_task(s['task'])),'Argumentation backend or definitions changed; start a new session')
            require(s['policy']['version']==POLICY['version'],'Intervention policy changed; start a new session')
            if 'participant_model_version' in s:
                from .participant_model import VERSION as PARTICIPANT_MODEL_VERSION
                require(s['participant_model_version']==PARTICIPANT_MODEL_VERSION,'Participant model changed; start a new session')
            # Exact retries are idempotent. Different repeated payloads still fail validation.
            for e in s['events']:
                if e['input']==data:return e
            candidate,event=ingest(s,data,now())
            self.save(candidate);return event

    def finish(self,sid,data):
        fields(data,['completed'])
        require(type(data['completed']) is bool,'Invalid completion state')
        with self.lock:
            s=self.get(sid)
            if s['finished']:
                require(s['completed']==data['completed'],'Session already closed with different status')
                return s
            require(not data['completed'] or len(history(s))==s['total_trials'],'Cannot complete an unfinished protocol')
            s['finished']=True;s['completed']=data['completed'];s['finished_at']=now()
            s['profile']=calibration_profile(s['task'],history(s)) if s['phase']=='calibration' and s['completed'] else None
            self.save(s);return s

    def replay(self,sid):
        original=self.get(sid)
        require(original.get('argumentation_configuration',{}).get('mode')=='live','Historical replay requires its recorded software version; stored JSON and RDF remain available')
        require(original['configuration_digest']==digest({k:original[k] for k in configuration_fields(original)}),'Recorded configuration hash does not match; settings were altered')
        if 'language_configuration' in original:
            require(original['language_configuration']['grounding_version']==GROUNDING_VERSION,'Replay requires the recorded grounding version')
        expected={'policy':POLICY,'model_version':VERSION,'schema_version':SCHEMA_VERSION if 'task_module' in original else 'ontology-0.1','network':NETWORK.describe()}
        if 'task_module' in original:expected['task_module']=get_task(original['task']).describe()
        if 'argumentation_configuration' in original:expected['argumentation_configuration']=argumentation_configuration(get_task(original['task']))
        if 'participant_model_version' in original:
            from .participant_model import VERSION as PARTICIPANT_MODEL_VERSION
            expected['participant_model_version']=PARTICIPANT_MODEL_VERSION
        # Reject model/policy drift rather than pretending a new model reproduces an old run.
        for key,value in expected.items():
            require(original[key]==value,'Replay requires recorded '+key+' version/backend; current runtime differs')
        restored=copy.deepcopy(original);restored['events']=[];restored['finished']=False;restored['completed']=False
        restored['preference']=original['initial_preference']
        for event in original['events']:
            language=event.get('snapshot',{}).get('decision',{}).get('language')
            restored,new=ingest(restored,event['input'],event['timestamp'],language,
                                recorded_interpretation=event.get('interpretation'),replaying=True)
            require(new==event,'Replay mismatch at '+event['id'])
        restored['finished']=original['finished'];restored['completed']=original['completed']
        return {'matches':True,'events_replayed':len(restored['events']),'digest':digest(restored['events']),
                'recorded_digest':digest(original['events']),'api_calls':0}

    def export(self,sid):
        s=self.get(sid)
        from .analysis import summarize
        s['summary']=summarize(s)
        s['export']={'event_digest':digest(s['events']),'information_boundary':'Participant-visible events only. Evaluator logs are a separate browser download.'}
        return s
